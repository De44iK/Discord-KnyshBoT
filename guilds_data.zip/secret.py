# WARNING! #
# This part of the code contains ALL THE PRIVATE information and must NOT be published!

BOT_TOKEN_RELEASE = "MTEzNjUwOTQyOTI5NTA4NzY2Ng.G2M_Cx.EtzNmDevyLI2tuyGSijDoKhWz8YDplgfe24YkI"  # Token of KnyshBoT#3700
BOT_TOKEN_TESTING = "MTEyMTEyNDgzMTUxNDA3NTMyOA.GLx6Cc.tiLQgjqrBwJMs6kRj1eUPlP1-gnT13WXwZezt4"  # Token of ГосУслуги#1708
WEATHER_API_KEY = "8959e5c8fb888e8592bc1a829ab57da3"  # OpenWeatherMap API Key (PRIVATE)

# An Invite Link for KnyshBoT#3700
BOT_INVITE_LINK_RELEASE = "https://discord.com/api/oauth2/authorize?client_id=1136509429295087666&permissions=8&scope=bot"

# An Invite Link for ГосУслуги#1708
BOT_INVITE_LINK_TESTING = "https://discord.com/api/oauth2/authorize?client_id=1121124831514075328&permissions=8&scope=bot"

ADMIN_PWRD = "AACBB"
