BOT_PREFIX = "/"  # bot command prefix
BOT_MODE = "RELEASE"  # choose TESTING or RELEASE bot


